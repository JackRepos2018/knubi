
(function () {

	'use strict';

	/**
	 * @constructor
	 */
	function AbstractBoot()
	{

	}

	AbstractBoot.prototype.bootstart = function ()
	{

	};

	module.exports = AbstractBoot;

}());