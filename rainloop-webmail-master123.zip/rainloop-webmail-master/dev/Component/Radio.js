
import {componentExportHelper} from 'Component/Abstract';
import {AbstracRadio} from 'Component/AbstracRadio';

class RadioComponent extends AbstracRadio {}

export default componentExportHelper(RadioComponent, 'RadioComponent');
