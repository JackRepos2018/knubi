
/**
 * @returns {AppUser}
 */
export function getApp() {
	return require('App/User').default;
}
