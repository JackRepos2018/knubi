Rainloop change password custom mysql plugin
============================================

This plugin adds change password capability to Rainloop webmail by write your own SQL statement

##### Installation is simple:

1. Drop the change-password-custom-sql in the plugins directory (eg. _RainLoopDir_/data/data_xxxxx/_default/plugins/*)
2. In rainloop admin panel go to Plugins, and activate change-password-custom-sql.
3. Enter mysql details on the plugin config screen.
